import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers/app_providers.dart';
import '../data/tools/tool_registry.dart';
import '../data/tools/builtin_tool_provider.dart';
import '../data/tools/calendar_service.dart';
import '../data/tools/location_service.dart';
import '../data/tools/mcp_tool_provider.dart';
import '../data/tools/tool_definition.dart';
import '../data/mcp_server_manager.dart';

final mcpServerManagerProvider = Provider<McpServerManager>((ref) {
  // Built once: rebuilding would drop every live server connection, so the
  // app version is applied when package info loads instead of watched.
  final manager = McpServerManager(
    appVersion: ref.read(packageInfoProvider).value?.version ?? '1.0.0',
  );
  ref.listen(packageInfoProvider, (_, next) {
    final version = next.value?.version;
    if (version != null) manager.appVersion = version;
  });
  return manager;
});

final calendarServiceProvider = Provider<CalendarService>(
  (ref) => CalendarService.instance,
);

final locationServiceProvider = Provider<LocationService>(
  (ref) => LocationService.instance,
);

final builtInToolProviderProvider = Provider<BuiltInToolProvider>((ref) {
  final settings = ref.watch(settingsProvider);
  return BuiltInToolProvider(
    calendarToolsEnabled: settings.calendarToolsEnabled,
    locationToolsEnabled: settings.locationToolsEnabled,
  );
});

final toolRegistryProvider = Provider<ToolRegistry>((ref) {
  final mcpServerManager = ref.watch(mcpServerManagerProvider);
  return ToolRegistry(
    providers: [
      ref.watch(builtInToolProviderProvider),
      McpToolProvider(serverManager: mcpServerManager),
    ],
  );
});

final availableToolsProvider = FutureProvider<List<ToolDefinition>>((
  ref,
) async {
  final registry = ref.watch(toolRegistryProvider);
  return registry.listTools();
});
