import 'dart:io';

/// Offline build: only explicit numeric LAN IPs or localhost can be used.
/// No DNS lookups are performed for remote names; no public Internet hosts.
class OfflineNetworkPolicy {
  const OfflineNetworkPolicy._();

  static bool isAllowedUrl(String input) {
    final uri = Uri.tryParse(input.trim());
    return uri != null && isAllowedUri(uri);
  }

  static bool isAllowedUri(Uri uri) {
    if (uri.scheme != 'http' && uri.scheme != 'https') return false;
    if (uri.userInfo.isNotEmpty || uri.host.isEmpty) return false;
    final host = uri.host.toLowerCase();
    if (host == 'localhost') return true;
    final ip = InternetAddress.tryParse(host);
    if (ip == null) return false; // never resolve DNS/public names
    if (ip.isLoopback || ip.isLinkLocal) return true;
    if (ip.type == InternetAddressType.IPv4) {
      final a = ip.rawAddress;
      return a[0] == 10 ||
          (a[0] == 172 && a[1] >= 16 && a[1] <= 31) ||
          (a[0] == 192 && a[1] == 168);
    }
    if (ip.type == InternetAddressType.IPv6) {
      final a = ip.rawAddress;
      return (a[0] & 0xfe) == 0xfc; // fc00::/7 unique-local
    }
    return false;
  }
}
