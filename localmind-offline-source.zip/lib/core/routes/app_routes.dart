import 'package:flutter/foundation.dart';

class AppRoutes {
  static const String home = '/';
  static const String onboarding = '/onboarding';
  static const String onboardingServerType = '/onboarding/server-type';
  static const String onboardingSetup = '/onboarding/setup';
  static const String onboardingTheme = '/onboarding/theme';
  static const String onboardingNotifications = '/onboarding/notifications';
  static const String servers = '/servers';
  static const String addServer = '/servers/add';
  static const String personas = '/personas';
  static const String createPersona = '/personas/create';
  static const String settings = '/settings';
  static const String localApi = '/settings/local-api';
  static bool get supportsLocalApi =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;
  static const String models = '/models';
  static const String chatHistory = '/history';
  static const String onDeviceModels = '/on-device-models';
  static const String addOnDeviceModel = '/on-device-models/add';
  static const String ttsModels = '/tts-models';
  static const String savedMessages = '/saved-messages';
}
