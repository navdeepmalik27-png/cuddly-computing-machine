# LocalMind: Local-Only Edition

**Your AI. Your Device. Your Rules.**

This community modification of the upstream LocalMind source targets an **offline on-device LLM experience**, with optional access to models served on **your own local network**. It is not the original upstream release.

## Supported functionality

- **Local model import:** Pick an existing `.gguf` (llama.cpp/llamadart) or `.litertlm` (LiteRT/Flutter Gemma) model from device storage.
- **Local chat:** Chat histories, saved messages, personas, local backup/restore, and on-device inference remain.
- **Private-LAN inference:** Connect to LM Studio, Ollama, or an OpenAI-compatible service at `localhost` or an explicit local/private IP address.
- **Local API server (Android):** Expose the loaded on-device model over the built-in local OpenAI-compatible API, under Settings.
- **No in-app model downloads:** Internet model catalogs, cloud accounts/providers, S3 sync, MCP networking, and app-store review prompts have been removed or disabled.

### What “offline” means here

This modified source uses an application-level network guard to reject requests through its HTTP clients to public addresses. Android's `INTERNET` permission is intentionally retained for localhost/LAN sockets. Only **numeric private IPs and `localhost`** are accepted in the server setup form. The project has not been runtime-audited for hidden network traffic from third-party or native dependencies.

### Build

The project uses Flutter 3.44+ and Dart 3.12+. Run in the project root:

```shell
flutter pub get
flutter gen-l10n
dart run build_runner build --delete-conflicting-outputs
dart analyze
flutter test
flutter build apk --release
```

See [`OFFLINE_BUILD_NOTES.md`](OFFLINE_BUILD_NOTES.md) for changes, compatibility notes, and verification caveats. The source was modified and statically checked; the APK was **not** built in this environment.

Upstream copyright and licensing are preserved in [`LICENSE`](LICENSE).
